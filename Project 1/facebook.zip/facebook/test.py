import os
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

def read_edges(filename):
    return pd.read_csv(filename, sep=' ', header=None, names=['node1', 'node2'])

data_directory = '.'  # Current directory
files = os.listdir(data_directory)

edges_data = {}

#get all files
for file in files:
    if file.endswith('.edges'):
        key = file.split('.edges')[0]
        edges_data[key] = read_edges(file)

#create a graph for the first network found
first_key = next(iter(edges_data))
G = nx.Graph()

# Add edges to the graph
for index, row in edges_data[first_key].iterrows():
    G.add_edge(row['node1'], row['node2'])

# Draw the network
plt.figure(figsize=(10, 10))
nx.draw(G, with_labels=True, node_size=50, font_size=8)
plt.title(f'Network Graph for {first_key}')
plt.show()